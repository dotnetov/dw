#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif

#ifndef EMISSIVE
in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif

in vec2 texCoord0;

out vec4 fragColor;

#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define DREADWAKE_SKIN_RIG
flat in int dreadwakePart;
const vec4[] subuvs = vec4[](
    vec4(4.0,  0.0,  8.0,  4.0 ),
    vec4(8.0,  0.0,  12.0, 4.0 ),
    vec4(0.0,  4.0,  4.0,  16.0),
    vec4(4.0,  4.0,  8.0,  16.0),
    vec4(8.0,  4.0,  12.0, 16.0),
    vec4(12.0, 4.0,  16.0, 16.0),
    vec4(4.0,  0.0,  7.0,  4.0 ),
    vec4(7.0,  0.0,  10.0, 4.0 ),
    vec4(0.0,  4.0,  4.0,  16.0),
    vec4(4.0,  4.0,  7.0,  16.0),
    vec4(7.0,  4.0,  11.0, 16.0),
    vec4(11.0, 4.0,  14.0, 16.0),
    vec4(4.0,  0.0,  12.0, 4.0 ),
    vec4(12.0,  0.0, 20.0, 4.0 ),
    vec4(0.0,  4.0,  4.0,  16.0),
    vec4(4.0,  4.0,  12.0, 16.0),
    vec4(12.0, 4.0,  16.0, 16.0),
    vec4(16.0, 4.0,  24.0, 16.0)
);

const vec2[] origins = vec2[](
    vec2(40.0, 16.0),
    vec2(40.0, 32.0),
    vec2(32.0, 48.0),
    vec2(48.0, 48.0),
    vec2(16.0, 16.0),
    vec2(16.0, 32.0),
    vec2(0.0,  16.0),
    vec2(0.0,  32.0),
    vec2(16.0, 48.0),
    vec2(0.0,  48.0)
);
vec2 skinCoordinates(vec2 uv, int part) {
    vec2 pixel = uv * 64.0;
    int layer = int(pixel.x / 32.0);
    pixel.x -= float(layer) * 32.0;
    ivec2 tile = ivec2(floor(pixel / 8.0));
    int face = tile.y == 0 ? (tile.x == 1 ? 0 : 1) : 2 + tile.x;
    int limb = part % 5;
    vec4 sample1 = texelFetch(Sampler0, ivec2(54, 20), 0);
    vec4 sample2 = texelFetch(Sampler0, ivec2(55, 20), 0);
    bool slim = sample1.a == 0.0 || (sample1.rgb == vec3(0.0) && sample2.rgb == vec3(0.0) && sample1.a == 1.0 && sample2.a == 1.0);
    int index = face + (slim && limb < 2 ? 6 : limb == 2 ? 12 : 0);
    vec4 rect = subuvs[index];
    if (face >= 2 && limb != 2) {
        rect.w -= 6.0;
        if (part >= 5) rect.yw += 6.0;
    }
    vec2 within = pixel / 8.0 - vec2(tile);
    return (origins[2 * limb + layer] + mix(rect.xy, rect.zw, within)) / 64.0;
}
#endif

void main() {
    vec2 uv = texCoord0;
#ifdef DREADWAKE_SKIN_RIG
    if (dreadwakePart >= 0) uv = skinCoordinates(uv, dreadwakePart);
#endif
    vec4 color = texture(Sampler0, uv);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
