#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec4 position = ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
#ifdef IS_GUI
    ivec3 marker = ivec3(round(Color.rgb * 255.0));
    int encoded = marker.b - 192;
    int count = encoded / 8 + 1;
    int kind = encoded % 8;
    int row = marker.g - 224;
    bool portrait = marker.r >= 249 && marker.r <= 253 && kind == 6;
    if (marker.r == 232 && marker.g >= 224 && marker.g <= 225 && marker.b >= 192 && marker.b <= 193) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 edge = step(vec2(0.5), UV0);
        position.xy = (vec2(float(marker.g - 224), float(marker.b - 192)) + edge) * vec2(width, height) * 0.5;
        position.z += 0.5;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    } else if (marker == ivec3(227, 224, 192)) {
        position.y += 5.0;
        vertexColor = vec4(163.0 / 255.0, 171.0 / 255.0, 176.0 / 255.0, Color.a);
    } else if (marker == ivec3(231, 224, 192)) {
        position.z += 1.0;
        vertexColor = vec4(232.0 / 255.0, 189.0 / 255.0, 114.0 / 255.0, Color.a);
    } else if (marker.r == 229 && row >= 0 && row <= 1 && encoded >= 0 && encoded <= 2) {
        float width = 2.0 / abs(ProjMat[0][0]);
        vec2 base = vec2(floor(width * 0.5 + 0.0001) + (row == 1 ? 81.0 : -96.0), row == 1 ? 13.0 : 3.0);
        vec2 local = position.xy - base;
        position.z += 6.0;
        if (encoded == 0) {
            position.xy = vec2(width - 184.0, 10.0) + local * vec2(172.0 / 128.0, 20.0 / 16.0);
            position.z -= 1.0;
        } else position.xy = vec2(width - 20.0, 16.0) + local;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    } else if (marker.r == 230 && row == 0 && encoded >= 0 && encoded <= 7) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 3.0);
        float panelWidth = min(300.0, width - 16.0);
        float left = (width - panelWidth) * 0.5;
        vec3 tint = vec3(1.0);
        position.z += 5.0;
        if (encoded == 0) {
            position.xy = vec2(left, 42.0) + local * vec2(panelWidth/128.0, 1.0);
            position.z -= 1.0;
        } else {
            vec2 origin = vec2(left + 12.0, 50.0);
            if (encoded == 2 || encoded == 3) { origin.y = 66.0; tint = vec3(0.66, 0.70, 0.72); }
            if (encoded == 6 || encoded == 7) origin.y = 78.0;
            if (encoded == 3 || encoded == 7) origin.x = width * 0.5 + 10.0;
            position.xy = origin + local;
            if (encoded == 4) position.xy = vec2(width*0.5, height-43.0) + local;
            if (encoded == 5) position.xy = vec2(width*0.5, height-27.0) + local;
        }
        vertexColor = vec4(tint,Color.a);
    } else if (marker.r == 226 && row >= 0 && row <= 4 && encoded >= 0 && encoded <= 9) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        float scale = min(1.0, min(width / 200.0, height / 100.0));
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 3.0);
        vec2 origin = vec2(width - 188.0 * scale, height - 86.0 * scale);
        vec3 tint = vec3(1.0);
        float factor = 1.0;
        position.z += 5.0;
        if (encoded == 0) position.z -= 1.0;
        else if (encoded == 1) origin += vec2(9.0, 8.0) * scale;
        else if (encoded == 2) { origin += vec2(98.0, 8.0) * scale; tint = row == 1 ? vec3(0.60,0.86,0.62) : vec3(0.62); }
        else if (encoded == 3) { origin += vec2(13.0 + float(row)*30.0,22.0) * scale; position.z -= 0.5; }
        else if (encoded == 4) origin += vec2(14.0 + float(row)*30.0,23.0) * scale;
        else if (encoded == 5) { origin += vec2(14.0 + float(row)*30.0,23.0) * scale; factor = 3.0; local.y += 1.0; }
        else if (encoded == 6) { origin += vec2(22.0 + float(row)*30.0,49.0) * scale; local.y -= 4.0; }
        else if (encoded == 7) { origin += vec2(9.0,60.0) * scale; tint=vec3(0.78); }
        else if (encoded == 8) { origin += vec2(88.0,row == 0 ? 54.0 : 60.0) * scale; tint=vec3(0.70); }
        else if (encoded == 9) { origin += vec2(88.0,64.0) * scale; tint=vec3(0.70); }
        position.xy = origin + local * factor * scale;
        vertexColor = vec4(tint, Color.a);
    } else if (marker.r == 235 && row >= 0 && row < 8 && encoded >= 0 && encoded <= 32) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 3.0);
        float scale = min(width / 480.0, height / 270.0);
        float factor = 1.0;
        position.z += 4.0;
        vec2 origin = vec2(18.0, 18.0) * scale;
        vec3 tint = vec3(0.88);
        if (encoded == 0) {
            position.xy = local * vec2(width / 128.0, height / 72.0);
            position.z -= 3.0;
        } else {
            if (encoded == 1) { origin = vec2(10.0, 52.0) * scale; position.z -= 2.0; }
            else if (encoded == 2) { factor = 1.5; tint = vec3(0.96, 0.16, 0.20); }
            else if (encoded == 3) origin = vec2(18.0, 38.0) * scale;
            else if (encoded == 4) { origin = vec2(40.0 + float(row) * 60.0, 67.0) * scale; factor = 0.68; }
            else if (encoded == 5) { origin = vec2(25.0 + float(row) * 60.0, 89.0) * scale; factor = 1.25; }
            else if (encoded == 6) { origin = vec2(40.0 + float(row) * 60.0, 128.0) * scale; factor = 1.3; tint = vec3(1.0); }
            else if (encoded == 7) origin = vec2(20.0 + float(row) * 60.0, 145.0) * scale;
            else if (encoded == 8) { origin = vec2(40.0 + float(row) * 60.0, 156.0) * scale; factor = 0.75; tint = vec3(0.58); }
            else if (encoded == 9) { origin = vec2(row == 0 ? 18.0 : 67.0, row == 0 ? 179.0 : 175.0) * scale; factor = row == 0 ? 1.0 : 1.8; tint = vec3(1.0); }
            else if (encoded == 10) origin = vec2(18.0, 205.0) * scale;
            else if (encoded == 11) { origin = vec2(width - 18.0 * scale, 18.0 * scale); tint = vec3(0.94, 0.30, 0.35); }
            else if (encoded == 12) origin = vec2(width - 18.0 * scale, (35.0 + float(row) * 12.0) * scale);
            else if (encoded == 13) { origin = vec2(21.0, 79.0 + float(row) * 25.0) * scale; factor = 2.0; }
            else if (encoded == 14) origin = vec2(43.0, 79.0 + float(row) * 25.0) * scale;
            else if (encoded == 15) { origin = vec2(235.0, 79.0 + float(row) * 25.0) * scale; tint = vec3(1.0); }
            else if (encoded == 16) { origin = vec2(43.0, 89.0 + float(row) * 25.0) * scale; factor = 0.75; tint = vec3(0.60); }
            else if (encoded >= 17 && encoded <= 20) { origin = vec2(133.0 + float(encoded - 17) * 16.0, 87.0 + float(row) * 25.0) * scale; factor = 0.35; }
            else if (encoded == 21) origin = vec2(18.0 * scale, height - 43.0 * scale);
            else if (encoded == 22) origin = vec2(width - 128.0 * scale, height - 25.0 * scale);
            else if (encoded == 23) origin = vec2((18.0 + float(row) * 13.0) * scale, height - 25.0 * scale);
            else if (encoded == 24) { origin = vec2(18.0, 75.0 + float(row) * 25.0) * scale; position.z -= 1.0; }
            else if (encoded == 25) { origin = vec2(row == 0 ? 43.0 : 235.0, 60.0) * scale; tint = vec3(0.6); factor = 0.8; }
            else if (encoded == 26) origin = vec2(18.0, 168.0) * scale;
            else if (encoded == 27) { origin = vec2(18.0 * scale, height - 43.0 * scale); local.y -= 2.5; }
            else if (encoded == 28) { origin = vec2(width - 128.0 * scale, height - 25.0 * scale); local.y -= 2.5; }
            else if (encoded == 29) { origin = vec2(width - 18.0 * scale, 18.0 * scale); tint = vec3(1.0); }
            else if (encoded == 30) { factor = 1.5; tint = vec3(1.0); }
            else if (encoded == 31) { origin = vec2(235.0, 60.0) * scale; factor = 0.8; tint = vec3(1.0); }
            else if (encoded == 32) { origin = vec2(18.0 * scale, height - 43.0 * scale); tint = vec3(1.0); }
            position.xy = origin + local * scale * factor;
        }
        if (encoded == 0 || encoded == 1 || encoded == 5 || encoded == 7 || encoded == 13 || encoded >= 17 && encoded <= 20 || encoded == 23 || encoded == 24 || encoded == 26) tint = vec3(1.0);
        vertexColor = vec4(tint, Color.a);
    }
    else if (marker.r == 234 && row >= 0 && row <= 4 && encoded >= 0 && encoded <= 5) {
        float width = 2.0 / abs(ProjMat[0][0]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 22.0);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 origin = vec2(12.0, floor(height * 0.62));
        if (encoded == 3) origin += vec2(17.0, 2.0);
        position.z += 2.0;
        position.xy = origin + local * (encoded == 1 ? 1.3 : 1.0);
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    else if (marker.r == 237 && row >= 0 && row <= 15 && encoded >= 0 && encoded <= 3) {
        float width = 2.0 / abs(ProjMat[0][0]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 22.0);
        float opacity = float(row) / 15.0;
        float slide = 12.0 * (1.0 - opacity);
        vec2 origin = vec2(width - 184.0 + slide, 18.0);
        float factor = 1.0;
        vec3 tint = vec3(1.0);
        if (encoded == 1) origin = vec2(width - 42.0 + slide, 22.0);
        else if (encoded == 2) { origin = vec2(width - 50.0 + slide, 25.0); factor = 0.85; tint = vec3(0.94); }
        else if (encoded == 3) { origin = vec2(width - 50.0 + slide, 36.0); factor = 0.8; tint = vec3(0.91, 0.22, 0.27); }
        position.xy = origin + local * factor;
        position.z += encoded == 0 ? 1.0 : 2.0;
        vertexColor = vec4(tint, Color.a * opacity);
    }
    else if (marker.r == 233 && row >= 0 && row < 8 && encoded >= 0 && encoded <= 2) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 22.0);
        float columns = max(1.0, floor((width - 24.0) / 40.0));
        float column = mod(float(row), columns);
        float level = floor(float(row) / columns);
        vec2 origin = vec2(width - 44.0 - column * 40.0, max(4.0, height * 0.5 - 72.0) - level * 44.0);
        if (encoded == 2) origin += vec2(7.0, 35.0);
        position.xy = origin + local;
        position.z += encoded == 0 ? 1.0 : 2.0;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    else if ((marker.r == 236 || marker.r == 239) && row >= 0 && row <= 4 && encoded >= 0 && encoded <= 5) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 22.0);
        if (marker.r == 239) position.xy = vec2(floor(width * 0.5) - 45.0, 14.0 + float(encoded) * 14.0) + local;
        else {
            float bottom = encoded == 0 ? 172.0 : encoded <= 2 ? 100.0 : encoded == 3 ? 68.0 : 84.0;
            if (encoded == 2 || encoded == 5) local.y -= 2.5;
            position.xy = vec2(floor(width * 0.5) - (encoded == 0 ? 32.0 : 56.0), height - bottom) + local;
        }
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    else if (marker.r == 238 && row >= 0 && row < 4 && encoded >= 0 && encoded < 32 && row < count) {
        float width = 2.0 / abs(ProjMat[0][0]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 3.0);
        position.xy = vec2(12.0, 16.0 + float(row) * 38.0) + (local + vec2(0.0, 1.0)) * 4.0;
        position.z += 2.0;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    else if (marker.r >= 240 && marker.r <= 242 && row >= 0 && row <= 4 && encoded >= 0 && encoded < 4) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 22.0);
        if (marker.r == 242) position.xy = vec2(width - 84.0 + float(kind % 2) * 40.0, height - 84.0 + float(kind / 2) * 40.0) + local;
        else if (marker.r == 241) position.xy = vec2(floor(width * 0.5) - 72.0, height - 68.0) + local;
        else position.xy = vec2(floor(width * 0.5), height - 84.0) + local;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    else if (marker.r == 243 && row >= 0 && row < 4 && encoded >= 0 && encoded < 32 && row < count) {
        float width = 2.0 / abs(ProjMat[0][0]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 3.0);
        position.xy = vec2(54.0, 27.0 + float(row) * 38.0) + local;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    else if (marker.r >= 244 && marker.r <= 248 && row >= 0 && row <= 4 && encoded >= 0 && encoded < 16 && kind < count) {
        float width = 2.0 / abs(ProjMat[0][0]);
        float height = 2.0 / abs(ProjMat[1][1]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 22.0);
        vec2 origin = vec2(floor(width * 0.5) - (float(count) * 46.0 - 6.0) * 0.5 + float(kind) * 46.0, height - 60.0);
        position.xy = origin + local;
        if (marker.r == 247) { position.xy += vec2(30.0, 28.0); position.z += 1.0; }
        if (marker.r == 246) position.xy += vec2(20.0, 44.0);
        if (marker.r == 245) { position.xy += vec2(5.0, 4.0); position.z += 1.0; }
        if (marker.r == 244) position.xy = vec2(floor(width * 0.5), height - 82.0) + local;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    else if ((marker.r == 254 || portrait) && row >= 0 && row < 4 && encoded >= 0 && encoded < 32
            && kind >= 0 && kind <= 7 && row < count) {
        float width = 2.0 / abs(ProjMat[0][0]);
        vec2 local = position.xy - vec2(floor(width * 0.5 + 0.0001) - 96.0, 3.0);
        vec2 origin = vec2(12.0, 16.0 + float(row) * 38.0);
        if (kind == 6) position.xy = origin + (local + vec2(0.0, 1.0)) * 4.0;
        else if (kind >= 1 && kind <= 5) {
            position.xy = origin + (local + vec2(0.0, 1.0)) * 4.0;
            position.z += 1.0;
        }
        else if (kind == 7) position.xy = origin + vec2(42.0, 20.0) + local * 2.0;
        else position.xy = origin + vec2(42.0, 3.0) + local * 1.25;
        vec3 tint = vec3(1.0);
        if (portrait && marker.r == 250) tint = vec3(0.85, 0.45, 0.45);
        if (portrait && marker.r == 251) tint = vec3(0.45);
        if (portrait && marker.r == 253) tint = vec3(0.3);
        vertexColor = vec4(tint, Color.a);
    }
#endif
    gl_Position = ProjMat * position;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#endif
    texCoord0 = UV0;
}
