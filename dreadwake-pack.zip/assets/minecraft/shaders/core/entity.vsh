#version 330

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;
uniform sampler2D Sampler0;

#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif

#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif

#ifndef EMISSIVE
out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif

out vec2 texCoord0;

#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define DREADWAKE_SKIN_RIG
#define SPACING 1024.0
#define MAXRANGE (0.5 * SPACING)
flat out int dreadwakePart;
#endif

void main() {
#ifdef DREADWAKE_SKIN_RIG
    dreadwakePart = -1;
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#ifndef EMISSIVE
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;
    ivec2 guardSize = textureSize(Sampler0, 0);
    if (abs(ProjMat[2][3]) > 0.00001 && guardSize == ivec2(64, 64)
            && ivec4(round(texelFetch(Sampler0, ivec2(0, 0), 0) * 255.0)) == ivec4(17, 231, 93, 255)
            && ivec4(round(texelFetch(Sampler0, ivec2(63, 0), 0) * 255.0)) == ivec4(219, 41, 167, 255)
            && ivec4(round(texelFetch(Sampler0, ivec2(0, 63), 0) * 255.0)) == ivec4(73, 149, 251, 255)
            && ivec4(round(texelFetch(Sampler0, ivec2(63, 63), 0) * 255.0)) == ivec4(241, 107, 29, 255)) {
        vec2 corners[4] = vec2[](vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(1.0, 1.0), vec2(-1.0, 1.0));
        gl_Position = vec4(corners[gl_VertexID % 4], 1.0, 1.0);
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
        texCoord0 = vec2(0.5);
#ifdef PER_FACE_LIGHTING
        vertexPerFaceColorBack = vec4(0.0, 0.0, 0.0, 1.0);
        vertexPerFaceColorFront = vec4(0.0, 0.0, 0.0, 1.0);
#else
        vertexColor = vec4(0.0, 0.0, 0.0, 1.0);
#endif
#ifndef EMISSIVE
        lightMapColor = vec4(1.0);
#endif
#ifndef NO_OVERLAY
        overlayColor = vec4(0.0);
#endif
        return;
    }
#ifdef DREADWAKE_SKIN_RIG
    ivec2 dim = textureSize(Sampler0, 0);

    if (abs(ProjMat[2][3]) > 10e-6 && dim == ivec2(64, 64) && FogRenderDistanceEnd > FogRenderDistanceStart) {
        int partId = -int((Position.y - MAXRANGE) / SPACING);

        if (partId >= 1 && partId <= 10 && partId != 8) {
            dreadwakePart = partId - 1;
            vec3 wpos = Position;
            wpos.y += SPACING * partId;
            gl_Position = ProjMat * ModelViewMat * vec4(wpos, 1.0);

            sphericalVertexDistance = fog_spherical_distance(wpos);
            cylindricalVertexDistance = fog_cylindrical_distance(wpos);

            return;
        }
    }
#endif

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
